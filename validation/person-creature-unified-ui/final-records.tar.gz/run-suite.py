from pathlib import Path
import subprocess, os, json, sys, hashlib
from datetime import datetime, timezone

repo=Path('/workspace/seaart-unified-ui')
name,script=sys.argv[1:3]
out=Path(os.environ.get('RUN_RESULT_ROOT','/workspace/seaart-unified-ui-audit-20261012T062120Z/final-7'))/name
out.mkdir(parents=True,exist_ok=True)
assert not (out/'execution.json').exists(), 'Use a new output directory for every trial'
env={**os.environ,'TARGET_URL':'http://127.0.0.1:8765/seaart-unified-ui/index.html','BASELINE_URL':'http://127.0.0.1:8765/seaart-creature-motif-integration1/baseline/index.html','RESULT_DIR':str(out)}
stamp=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'command':(['node','tests/unified-ui/replay.cjs',script] if name in ['ui','pwa','pwa-regression','combined-pwa','normal-pwa','card-pwa','combined-ui'] else ['node',script]),'cwd':str(repo),'startUTC':stamp(),'gitHEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'productSHA256Before':sha(repo/'index.html'),'testSHA256':sha(repo/script),'env':{k:env[k] for k in ['TARGET_URL','BASELINE_URL','RESULT_DIR']},'publicOriginTest':False,'physicalDevice':False}
record['wrapperSHA256']=sha(repo/'tests/unified-ui/replay.cjs') if 'tests/unified-ui/replay.cjs' in record['command'] else None
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    run=subprocess.run(record['command'],cwd=repo,env=env,stdout=stdout,stderr=stderr)
record.update({'endUTC':stamp(),'exitCode':run.returncode,'productSHA256After':sha(repo/'index.html')})
(out/'execution.json').write_text(json.dumps(record,indent=2))
print(name,'exit',run.returncode,'product',record['productSHA256After'])
sys.exit(run.returncode)

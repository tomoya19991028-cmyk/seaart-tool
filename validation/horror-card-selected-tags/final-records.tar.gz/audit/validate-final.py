from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent;repo=Path('/workspace/seaart-card-tags');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=json.loads((root/'selected-final-runners.json').read_text());s['runners']['card-persistence']=str(root/'final-v6'/'card-persistence');counts={};records={}
for name,folder in s['runners'].items():
 d=Path(folder);x=json.loads((d/'execution.json').read_text());assert x['exitCode']==0;assert x['productSHA256Before']==x['productSHA256After']==sha(repo/'index.html');assert x['env']['TARGET_URL']=='http://127.0.0.1:8765/seaart-card-tags/index.html';assert x['testSHA256']==sha(repo/x['command'][-1])
 if 'tests/card-tags/replay.cjs' in x['command']:assert x['wrapperSHA256']==sha(repo/'tests/card-tags/replay.cjs')
 f={'legacy':'regression-results.json','r1':'r1-results.json','fixed':'final-fixed-comparison.json'}.get(name,'results.json');v=json.loads((d/f).read_text());assert v.get('passed',bool(v.get('tests')) and all(t.get('passed') is True for t in v['tests'])) is True,(name,v)
 if name=='r1':count=len(v['contracts']['checks']);assert count==49 and v['matrix']['checks']==865 and v['matrix']['baselineEqual']
 elif name=='legacy':count=v['adult'];assert v['normal']==v['manga']==252
 elif name=='motif':count=len(v['checks'])+len(v['faults'])+len(v['migration']);assert count==52
 elif name=='ui':count=len(v['T28'])+int(v['T27']['passed'])
 elif name=='pwa':count=len(v['T29'])+len(v['checks']);assert v['T30']['passed']
 elif name=='fixed':count=1;assert v['outputFingerprint']=='7d283415876bc135f201d347063f641fa33ef7f0cc341843d050908195693b5d'
 elif name=='faults':count=len(v['rows'])
 else:count=len(v.get('tests',v.get('checks',[])))
 counts[name]=count;records[name]={'resultPath':str(d),'exitCode':x['exitCode'],'cases':count,'productSHA256':x['productSHA256After'],'testSHA256':x['testSHA256'],'wrapperSHA256':x.get('wrapperSHA256')}
assert len(counts)==26 and sum(counts.values())==401,counts
s['cases']=counts;s['caseTotal']=401;(root/'selected-final-runners.json').write_text(json.dumps(s,indent=2));(root/'verified-results.json').write_text(json.dumps({'runnerCount':26,'passed':401,'failed':0,'notRunCreatedAutomated':0,'originalRound2TestFilesUnrecovered':3,'productSHA256':sha(repo/'index.html'),'runners':records},indent=2));print('VERIFIED 26 runners / 401 PASS / 0 FAIL',counts)

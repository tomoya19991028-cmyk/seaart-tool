from pathlib import Path
import subprocess,os,json,time
root=Path(__file__).resolve().parent
jobs=[('card-contracts','tests/card-tags/contracts.cjs'),('card-ui','tests/card-tags/ui.cjs'),('card-pwa','tests/card-tags/pwa.cjs'),('card-persistence','tests/card-tags/persistence.cjs'),('normal-contracts','tests/normal-first/contracts.cjs'),('normal-ui','tests/normal-first/ui.cjs'),('normal-pwa','tests/normal-first/pwa.cjs'),('contracts','tests/horror/contracts.cjs'),('faults','tests/horror/faults.cjs'),('r1','tests/creature-motif-person-r1.cjs'),('legacy','tests/horror/replay-legacy.cjs'),('boundaries','tests/horror/boundaries.cjs'),('motif','tests/creature-motif-person.cjs'),('motif-boundaries','tests/creature-motif-person-boundaries.cjs'),('edges','tests/horror/independent-edges.cjs'),('round2-retest','tests/integration/motif-round2-alternative.cjs'),('ui','tests/horror/ui.cjs'),('pwa-regression','tests/horror/replay-pwa.cjs'),('integration','tests/integration/horror-motif.cjs'),('prompts','tests/horror/independent-prompts.cjs'),('combined-pwa','tests/integration/pwa.cjs'),('pwa','tests/horror/pwa.cjs'),('ui-extra','tests/horror/independent-ui.cjs'),('combined-ui','tests/integration/ui.cjs'),('motif-prompts','tests/integration/motif-prompts.cjs'),('fixed','tests/creature-motif-person-fixed-baseline.cjs')]
ours={};announced=set()
def live():
 names=set()
 for d in Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:cmd=(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  except OSError:continue
  prefix='python '+str(root/'run-suite.py')+' '
  if cmd.startswith(prefix):names.add(cmd[len(prefix):].split()[0])
 return names
while True:
 running=live();complete={};pending=[]
 for name,script in jobs:
  record=root/'final-v4'/name/'execution.json'
  if record.exists():
   value=json.loads(record.read_text());complete[name]=value['exitCode']
   if name not in announced:print('COMPLETE',name,value['exitCode'],flush=True);announced.add(name)
  elif name not in running and name not in ours:pending.append((name,script))
 if len(complete)==len(jobs):
  (root/'scheduler-final-result.json').write_text(json.dumps(complete,indent=2));print('ALL COMPLETE',len(complete),'failures',[n for n,c in complete.items() if c],flush=True);break
 if len(running)<3 and int(Path('/sys/fs/cgroup/memory.current').read_text())<5500000000:
  for name,script in pending:
   if name=='fixed' and complete.get('r1')!=0:continue
   env={**os.environ}
   if name=='fixed':
    folder=root/'final-v4'/'fixed';folder.mkdir(exist_ok=True);link=folder/'baseline'
    if not link.exists():link.symlink_to('/workspace/seaart-creature-motif-integration1/baseline',target_is_directory=True)
    env['CURRENT_RESULTS']=str(root/'final-v4'/'r1'/'r1-generation-fulltext.json')
   ours[name]=subprocess.Popen(['python',str(root/'run-suite.py'),name,script],env=env,cwd='/workspace/seaart-card-tags');print('START',name,flush=True);break
 for name,p in list(ours.items()):
  if p.poll() is not None:ours.pop(name)
 time.sleep(3)

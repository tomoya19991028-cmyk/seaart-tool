from pathlib import Path
import ast,hashlib,json,subprocess,os,time
root=Path(__file__).resolve().parent;repo=Path('/workspace/seaart-card-tags');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();product=sha(repo/'index.html');wrapper=sha(repo/'tests/card-tags/replay.cjs')
tree=ast.parse((root/'schedule.py').read_text());jobs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='jobs' for t in n.targets));selected={};pending=[]
for name,script in jobs:
 p=root/'final-v4'/name/'execution.json'
 if p.exists():
  v=json.loads(p.read_text());valid=v['exitCode']==0 and v['productSHA256Before']==v['productSHA256After']==product and v['testSHA256']==sha(repo/script) and (not v.get('wrapperSHA256') or v['wrapperSHA256']==wrapper)
  # Wrapped executions made before adding wrapper provenance need a fresh run.
  if 'tests/card-tags/replay.cjs' in v['command'] and not v.get('wrapperSHA256'):valid=False
  if name=='fixed' and any(n=='r1' for n,s in pending):valid=False
  if valid:selected[name]=str(p.parent);continue
 pending.append((name,script))
print('RETEST',len(pending),[n for n,s in pending],flush=True);running={};done={};failures=[]
while pending or running:
 assert sha(repo/'index.html')==product,'Product changed during final verification'
 for name,p in list(running.items()):
  if p.poll() is not None:
   folder=root/'final-v5'/name;v=json.loads((folder/'execution.json').read_text());assert v['productSHA256Before']==v['productSHA256After']==product
   selected[name]=str(folder);done[name]=p.returncode;running.pop(name);print('DONE',name,p.returncode,flush=True)
   if p.returncode:failures.append(name)
 if failures:raise SystemExit('Final failures: '+','.join(failures))
 if len(running)<3 and int(Path('/sys/fs/cgroup/memory.current').read_text())<5500000000:
  for i,(name,script) in enumerate(pending):
   if name=='fixed' and 'r1' not in selected:continue
   env={**os.environ,'RUN_RESULT_ROOT':str(root/'final-v5')}
   if name=='fixed':
    folder=root/'final-v5'/'fixed';folder.mkdir(parents=True,exist_ok=True);link=folder/'baseline'
    if not link.exists():link.symlink_to('/workspace/seaart-creature-motif-integration1/baseline',target_is_directory=True)
    env['CURRENT_RESULTS']=str(Path(selected['r1'])/'r1-generation-fulltext.json')
   running[name]=subprocess.Popen(['python',str(root/'run-suite.py'),name,script],env=env,cwd=repo);pending.pop(i);print('START',name,flush=True);break
 time.sleep(2)
(root/'selected-final-runners.json').write_text(json.dumps({'productSHA256':product,'wrapperSHA256':wrapper,'runnerCount':len(jobs),'runners':selected},indent=2));print('FINAL VERIFIED',len(jobs),flush=True)
